
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Users Management</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('users.create')); ?>"> Create New User</a>
        </div>
    </div>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>Email</th>
        <th>Roles</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <input type="hidden" id="ur" value="users/"/>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($user1->name); ?></td>
        <td><?php echo e($user1->email); ?></td>
        <td>
            <?php if(!empty($user1->getRoleNames())): ?>
            <?php $__currentLoopData = $user1->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="badge badge-success"><?php echo e($v); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </td>
        <td>
            <a class="btn btn-info" href="<?php echo e(route('users.show',['user'=>$user1->id])); ?>">Show</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-edit')): ?>
            <?php if($user1->type==1): ?>
            <a class="btn btn-primary" href="<?php echo e(route('users.edit',['user'=>$user1->id])); ?>">Edit</a>
            <?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
            <a href="javascript:void(0);" class="btn btn-danger" onclick="if (confirm('Are you sure?')) { $(this).find('form').submit();}">
                <form
                    action="<?php echo e(route('users.destroy',['user'=>$user1->id])); ?>"
                    method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                </form>
                <i class="mdi mdi-delete-sweep text-danger"></i><span> delete </span>
            </a>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $data1->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/users/index.blade.php ENDPATH**/ ?>