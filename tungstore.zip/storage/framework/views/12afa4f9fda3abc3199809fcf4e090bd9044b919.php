<div id="header">
		<div class="header-top">
			<div class="container">
				<div class="pull-left auto-width-left">
					<ul class="top-menu menu-beta l-inline">
						<li><a href=""><i class="fa fa-home"></i> Tây Sơn-Vũ Chính-Thái Bình</a></li>
						<li><a href=""><i class="fa fa-phone"></i> 0363325454</a></li>
					</ul>
				</div>
				<div class="pull-right auto-width-right">
					<ul class="top-details menu-beta l-inline">
						<?php if(!isset($data['user'])): ?>
						<li><a href="<?php echo e(route('signup')); ?>">Đăng kí</a></li>
						<li><a href="<?php echo e(route('login')); ?>">Đăng nhập</a></li>
						<li><a href="<?php echo e(route('forgot_password')); ?>">Quên Mật khẩu</a></li>
						<?php else: ?>
						<li><a href="<?php echo e(route('info')); ?>"><i class="fa fa-user"></i><?php echo e((isset($data['user'])) ? $data['user']->name : "Tài khoản"); ?></a></li>
							<li><a href="<?php echo e(route('logout')); ?>">Đăng xuất</a></li>
							<li><a href="<?php echo e(route('list')); ?>">Đơn hàng</a></li>
						<?php endif; ?>
					</ul>
				</div>
				<div class="clearfix"></div>
			</div> <!-- .container -->
		</div> <!-- .header-top -->
		<div class="header-body">
			<div class="container beta-relative">
				<div class="pull-left">
					<a href="/" id="logo"><img src="source/assets/dest/images/logo-cake.png" width="200px" alt=""></a>
				</div>
				<div class="pull-right beta-components space-left ov">
					<div class="space10">&nbsp;</div>
					<div class="beta-comp">
						<form action="<?php echo e(route('search')); ?>" role="search" method="get" id="searchform" action="/">
					        <input type="text" value="" name="key" id="s" placeholder="Nhập từ khóa..." />
					        <button class="fa fa-search" type="submit" id="searchsubmit"></button>
						</form>
					</div>

					<div class="beta-comp">
						<div class="cart">
							<div class="beta-select"><i class="fa fa-shopping-cart"></i> Giỏ hàng <?php echo e((isset($data['user'])) ? count($data['cart']) : "(Trống)"); ?>  <i class="fa fa-chevron-down"></i></div>
							<?php if(isset($data['user'])): ?>
							<div class="beta-dropdown cart-body">
							<?php $__currentLoopData = $data['cart']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="cart-item">
									<div class="media">
										<a class="pull-left" href="<?php echo e(route('product_detail',$cart->product->id)); ?>"><img src="<?php echo e(URL::asset('storage/'.$cart->product->images)); ?>" alt=""></a>
										<div class="media-body">
											<span class="cart-item-title"><?php echo e($cart->product->name); ?></span>
											<!-- <span class="cart-item-options">Size: XS; Colar: Navy</span> -->
											<span class="cart-item-amount"><?php echo e($cart->qty); ?> *<span><?php echo e(number_format($cart->product->price)); ?> ₫</span></span>
										</div>
									</div>
									<div class="delcart">
										<a href="<?php echo e(route('delcart',$cart->id)); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class="cart-caption">
									<div class="cart-total text-right">Tổng tiền: <span class="cart-total-value"><?php echo e(number_format($data['total'])); ?> ₫</span></div>
									<div class="clearfix"></div>

									<div class="center">
										<div class="space10">&nbsp;</div>
										<a href="<?php echo e(route('order')); ?>" class="beta-btn primary text-center">Đặt hàng <i class="fa fa-chevron-right"></i></a>
									</div>
								</div>
							</div>
							<?php endif; ?>
						</div> <!-- .cart -->
					</div>
				</div>
				<div class="clearfix"></div>
			</div> <!-- .container -->
		</div> <!-- .header-body -->
		<div class="header-bottom">
			<div class="container">
				<a class="visible-xs beta-menu-toggle pull-right" href="#"><span class='beta-menu-toggle-text'>Category</span> <i class="fa fa-bars"></i></a>
				<div class="visible-xs clearfix"></div>
				<nav class="main-menu">
					<ul class="l-inline ov">
						<li class="dis"><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
						<li class="dis"><a href="#">Sản phẩm</a>
							<ul class="sub-menu">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a href="<?php echo e(route('category',$category->id)); ?>"><?php echo e($category->name); ?></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</li>
						<li class="dis"><a href="<?php echo e(route('about')); ?>">Thông tin</a></li>
						<li class="dis"><a href="<?php echo e(route('contact')); ?>">Liên hệ</a></li>
					</ul>
					<div class="clearfix"></div>
				</nav>
			</div> <!-- .container -->
		</div> <!-- .header-bottom -->
	</div> <?php /**PATH D:\DATN\tungstore\resources\views/pages/layouts/header.blade.php ENDPATH**/ ?>