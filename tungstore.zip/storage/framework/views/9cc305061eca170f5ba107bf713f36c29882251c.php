
<?php $__env->startSection('content'); ?>

<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('forgot_password')); ?>" method="post" class="beta-form-checkout">
                <?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<h4>Quên mật khẩu</h4>
						<div class="space20">&nbsp;</div>

                        <?php if(session('thongbao')): ?>
                            <p class="text-success text-center">
                                <?php echo e(session('thongbao')); ?>

                            </p>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <p class="text-danger text-center">
                                <?php echo e(session('error')); ?>

                            </p>
                        <?php endif; ?>
				
						<div class="form-block">
							<label for="email">Email*</label>
							<input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Nhap email cua ban">
                            <?php if($errors->has('email')): ?>
                                <p class="text-danger mt-2"><?php echo e($errors->first('email')); ?></p>
                            <?php endif; ?>
						</div>
						<!-- <div class="form-block">
							<label for="password">Password*</label>
							<input type="password" id="password" name="password" value="<?php echo e(old('password')); ?>" placeholder="Nhap mat khau cua ban">
                            <?php if($errors->has('email')): ?>
                                <p class="text-danger mt-2"><?php echo e($errors->first('email')); ?></p>
                            <?php endif; ?>
						</div> -->
						<div class="form-block">
							<button type="submit" class="btn btn-primary">Send</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/pages/auth/forgot_password.blade.php ENDPATH**/ ?>