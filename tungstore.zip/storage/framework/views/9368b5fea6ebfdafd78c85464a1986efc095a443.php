


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Order Management</h2>
        </div>
        <div class="pull-right">
            <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('banner-create')): ?>
                <a class="btn btn-success" href="<?php echo e(route('orders.create')); ?>"> Create New Banner</a>
            <?php endif; ?> -->
        </div>
    </div>
</div>


<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>


<table class="table table-bordered">
  <tr>
     <th>STT</th>
     <th>Name</th>
     <th>Phone</th>
     <th>Total Money</th>
     <th>Status</th>
     <th>Payment</th>
     <!-- <th>Link</th> -->
     <th width="280px">Action</th>
  </tr>
  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($order->name); ?></td>
        <td><?php echo e($order->phone); ?></td>
        <td><?php echo e($order->total_money); ?></td>
        <td class="text-center align-middle">
            <?php if($order->status==1): ?>
            <p class="text-center"><span href="#" class="bg-secondary text-white p-1 pr-3 pl-3 rounded">Chưa xử lý</span></p>
            <?php elseif($order->status==2): ?>
            <p class="text-center"><span href="#" class="bg-primary text-white p-1 pr-3 pl-3 rounded">Đang giao hàng</span></p>

            <?php else: ?>
            <p class="text-center"><span href="#" class="bg-success text-white p-1 pr-3 pl-3 rounded">Thành công</span></p>
            <?php endif; ?>
        <td class="text-center align-middle">
            <?php if($order->payment==1): ?>
                <p class="text-center"><span href="#" class="text-white bg-info p-1 pr-3 pl-3 rounded">COD</span></p>
            <?php else: ?>
                <p class="text-center"><span href="#" class="text-dark bg-light p-1 pr-3 pl-3 rounded">ATM</span></p>
            <?php endif; ?>    
        </td>
        <td class="text-center">
            <!-- <input type="hidden" id="ur" value="orders/"/> -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order-list')): ?>
            <a class="btn btn-info" href="<?php echo e(route('orders.show',$order->id)); ?>">Show</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order-edit')): ?>
                <a class="btn btn-primary" href="<?php echo e(route('orders.edit',$order->id)); ?>">Edit</a>
            <?php endif; ?>
            <!-- <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order-delete')): ?>
            <a href="javascript:void(0);" class="ml-4 btn btn-danger" onclick="if (confirm('Are you sure?')) { $(this).find('form').submit();}">
                <form
                    action="<?php echo e(route('orders.destroy',['order'=>$order->id])); ?>"
                    method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="DELETE">
                </form>
                <i class="mdi mdi-delete-sweep text-danger"></i><span> delete </span>
            </a>
            <?php endif; ?> -->
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php echo e($orders->links()); ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/orders/index.blade.php ENDPATH**/ ?>