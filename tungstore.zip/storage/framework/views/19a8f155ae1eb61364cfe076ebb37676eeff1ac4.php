<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	Mật khẩu mới của bạn là: <?php echo e($rand); ?>

</body>
</html><?php /**PATH D:\DATN\tungstore\resources\views/mail_laymk.blade.php ENDPATH**/ ?>