


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Banner Management</h2>
        </div>
        <div class="pull-right">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('file-create')): ?>
            <form id="form_file" action="<?php echo e(route('media.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="image" id="input_file">
                <!-- <input type="submit" value="Upload"> -->
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<div id="alert_success" class="alert alert-success">
    <p>Delete image success</p>
</div>
<div id="alert_error" class="alert alert-danger">
    <p>Delete image error</p>
</div>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<script>
    $(document).ready(function(){
        $('#input_file').change(function(){
            var form = document.querySelector('#form_file');
            var data = new FormData(form);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: $('#form').attr("action"),
                type: 'POST',
                dataType: "JSON",
                data: data,
                processData: false,
                contentType: false,
                success: function (data, status)
                {
                    location.reload();
                },
                error: function (xhr, desc, err)
                {
                    location.reload();
                }
            });        
        });
      $('.btn_delete').on('click',function(){
          var element = $(this).parent();
       var fileName = $(this).find("img").attr("title");
       console.log(fileName);
            swal({ 
               title: "Are you sure?",
               icon: "warning",
               buttons: true,
               dangerMode: true,
               })
               .then((willDelete) => {
               if (willDelete) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: 'POST',
                        dataType: 'text',
                        data: {
                            _method: 'DELETE'
                        },
                        url: "/media/"+fileName,
                        success: function (data) {
                            if(data=="success"){
                                element.remove();
                                $('#alert_success').css("display", "block");
                                $('#alert_error').css("display", "none");
                                // alert(data);
                            }
                        },
                        error:function(data){
                            $('#alert_error').css("display", "block");
                            $('#alert_success').css("display", "none");
                            // alert("delete error");
                        }
                    });
               }
            });
        });
    });
 </script>

<div class="row" id="image_list">
    <?php $__currentLoopData = $fileNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fileName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item_image col-xl-2 col-md-4 col-sm-6 p-3">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('file-create')): ?>
                <div class="btn_delete">
                    <img src="<?php echo e(asset('assets/images/delete.png')); ?>" title="<?php echo e($fileName); ?>" alt="">
                </div>
            <?php endif; ?>
            <img class="item_img" src="<?php echo e(asset('storage/'.$fileName)); ?>" title ="<?php echo e(asset('storage/'.$fileName)); ?>" alt="<?php echo e($fileName); ?>">
            <label><?php echo e($fileName); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/media/index.blade.php ENDPATH**/ ?>