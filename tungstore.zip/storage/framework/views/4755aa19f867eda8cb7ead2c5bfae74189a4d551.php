
<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-lg-12 margin-tb">
      <div class="pull-left">
         <h2>Show Order</h2>
      </div>
      <div class="pull-right">
         <a class="btn btn-primary" href="<?php echo e(route('orders.index')); ?>"> Back</a>
      </div>
   </div>
</div>
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
   <strong>Whoops!</strong> There were some problems with your input.<br><br>
   <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </ul>
</div>
<?php endif; ?>
<div class="row">
   <div class="col-xs-4 col-sm-4 col-md-4">
      <h3 class="text-center pt-2 pb-2">Thông tin đơn hàng</h3>
      <table class="table">
         <tbody>
            <tr>
               <td>Name</td>
               <td><?php echo e($order->name); ?></td>
            </tr>
            <tr>
               <td>Phone</td>
               <td><?php echo e($order->phone); ?></td>
            </tr>
            <tr>
               <td>Adress</td>
               <td><?php echo e($order->adress); ?></td>
            </tr>
            <tr>
               <td>Total Money</td>
               <td><?php echo e(number_format($order->total_money)); ?></td>
            </tr>
            <tr>
               <td>Payment</td>
               <td>
                  <?php if($order->payment==1): ?>
                  <p><span href="#" class="text-white bg-info p-1 pr-3 pl-3 rounded">COD</span></p>
                  <?php elseif($order->payment==2): ?>
                  <p><span href="#" class="text-dark bg-light p-1 pr-3 pl-3 rounded">ATM</span></p>
                  <?php endif; ?>
               </td>
            </tr>
            <tr>
               <td>Status</td>
               <td>
                  <?php if($order->status==1): ?>
                  <p ><span href="#" class="bg-secondary text-white p-1 pr-3 pl-3 rounded">Chưa xử lý</span></p>
                  <?php elseif($order->status==2): ?>
                  <p ><span href="#" class="bg-primary text-white p-1 pr-3 pl-3 rounded">Đang giao hàng</span></p>
                  <?php else: ?>
                  <p ><span href="#" class="bg-success text-white p-1 pr-3 pl-3 rounded">Thành công</span></p>
                  <?php endif; ?>
               </td>
            </tr>
         </tbody>
      </table>
   </div>
   <div class="col-xs-1 col-sm-1 col-md-1"></div>
   <div class="col-xs-7 col-sm-7 col-md-7">
      <h3 class="text-center pt-2 pb-2">Chi tiết đơn hàng</h3>
      <table class="table">
         <thead class="thead-dark">
            <tr>
               <th scope="col">#</th>
               <th scope="col">Image</th>
               <th scope="col">Name</th>
               <th scope="col">Price</th>
               <th scope="col">Amount</th>
            </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $order->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <th scope="row">1</th>
               <td><img width="25%" src="<?php echo e(URL::asset('storage/'.$item->product->images)); ?>" alt="" class="pull-left"></td>
               <td><?php echo e($item->product->name); ?></td>
               <td><?php echo e($item->product->price); ?></td>
               <td><?php echo e($item->qty); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/orders/show.blade.php ENDPATH**/ ?>