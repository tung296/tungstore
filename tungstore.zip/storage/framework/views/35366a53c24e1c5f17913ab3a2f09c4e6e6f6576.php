<div id="footer" class="color-div">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="widget">
						<!-- <h4 class="widget-title">Instagram Feed</h4> -->
						<div id="beta-instagram-feed1">
						<a href="/" id="logo"><img src="source/assets/dest/images/logo-cake.png" width="200px" alt=""></a>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="widget">
						<h4 class="widget-title">Thông tin</h4>
						<div>
						<p class="text-justify">Tùng Shop thành lập năm 2019. Chúng tôi chuyên cung cấp các sản phẩm điện thoại di động Cũ - Mới. Nhập đặt hàng đối với những sản phẩm sắp ra mắt</p>
						</div>
					</div>
				</div>
				<div class="col-sm-3">
				 <div class="col-sm-10">
					<div class="widget">
						<h4 class="widget-title">Liên hệ</h4>
						<div>
							<div class="contact-info1">
								<!-- <i class="fa fa-map-marker"></i> -->
								<p>Address 1: Vũ Chính - Thái Bình - Thái Bình</p>
								<p>Address 2: Cầu Sơn Tiến - Quyết Thắng - Thái Nguyên.</p>
							</div>
						</div>
					</div>
				  </div>
				</div>
				<div class="col-sm-3">
				 <div class="col-sm-12">
					<div class="widget">
						<h4 class="widget-title">Hotline</h4>
						<div>
							<div class="contact-info1">
								<!-- <i class="fa fa-map-marker"></i> -->
								<p>Phone Sale: (+84) 363325454</p>
								<p>Email: tungtuong98@gmail.com.</p>
							</div>
						</div>
					</div>
				  </div>
				</div>
				<!-- <div class="col-sm-3">
					<div class="widget">
						<h4 class="widget-title">Newsletter Subscribe</h4>
						<form action="#" method="post">
							<input type="email" name="your_email">
							<button class="pull-right" type="submit">Subscribe <i class="fa fa-chevron-right"></i></button>
						</form>
					</div>
				</div> -->
			</div> <!-- .row -->
		</div> <!-- .container -->
	</div> <!-- #footer -->
	<div class="copyright">
		<div class="container">
			<p class="pull-left">Privacy policy. (&copy;) 2021</p>
			<!-- <p class="pull-right pay-options">
				<a href="#"><img src="source/assets/dest/images/pay/master.jpg" alt="" /></a>
				<a href="#"><img src="source/assets/dest/images/pay/pay.jpg" alt="" /></a>
				<a href="#"><img src="source/assets/dest/images/pay/visa.jpg" alt="" /></a>
				<a href="#"><img src="source/assets/dest/images/pay/paypal.jpg" alt="" /></a>
			</p> -->
			<div class="clearfix"></div>
		</div> <!-- .container -->
	</div> <!-- .copyright --><?php /**PATH D:\DATN\tungstore\resources\views/pages/layouts/footer.blade.php ENDPATH**/ ?>