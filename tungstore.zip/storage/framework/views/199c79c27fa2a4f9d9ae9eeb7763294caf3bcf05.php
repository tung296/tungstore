<div class="iq-sidebar">
   <div class="iq-sidebar-logo d-flex justify-content-between">
      <a href="index.html" class="header-logo">
         <img src="assets/images/logo.png" class="img-fluid rounded-normal" alt="">
         <!-- <div class="logo-title">
            <span class="text-danger text-uppercase">Server<span class="text-primary ml-1">360</span></span>
         </div> -->
      </a>
      <div class="iq-menu-bt-sidebar">
         <div class="iq-menu-bt align-self-center">
            <div class="wrapper-menu">
               <div class="main-circle"><i class="ri-arrow-left-s-line"></i></div>
               <div class="hover-circle"><i class="ri-arrow-right-s-line"></i></div>
            </div>
         </div>
      </div>
   </div>
   <div id="sidebar-scrollbar">
      <nav class="iq-sidebar-menu">
         <ul id="iq-sidebar-toggle" class="iq-menu">
            <li class="active active-menu">
               <a href="#dashboard" class="iq-waves-effect" data-toggle="collapse" aria-expanded="true"><span class="ripple rippleEffect"></span><i class="las la-home iq-arrow-left"></i><span>Dashboard</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <ul id="dashboard" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                  <li class="active"><a href="index.html"><i class="las la-house-damage"></i>Server Monitoring</a></li>
                  <li><a href="dashboard-1.html"><i class="las la-landmark"></i>Website Monitoring</a></li>
                  <li><a href="dashboard-2.html"><i class="las la-warehouse"></i>API Monitoring</a></li>
               </ul>
            </li>
            <!-- <li>
               <a href="calendar.html" class="iq-waves-effect"><i class="las la-calendar iq-arrow-left"></i><span>Calendar</span></a>
               </li> -->
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
               <a href="<?php echo e(route('users.index')); ?>" class="iq-waves-effect"  aria-expanded="false"><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>User</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-list')): ?>
               <a href="<?php echo e(route('permissions.index')); ?>" class="iq-waves-effect"  aria-expanded="false"><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Permission</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
            <li>
               <!-- <a href="#roleinfo" class="iq-waves-effect" data-toggle="collapse" aria-expanded="false"><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Role</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a> -->
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
               <a href="<?php echo e(route('roles.index')); ?>" class="iq-waves-effect" ><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Role</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?> 
            </li>
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category-list')): ?>
               <a href="<?php echo e(route('categories.index')); ?>" class="iq-waves-effect" ><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Category</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('banner-list')): ?>
               <a href="<?php echo e(route('banners.index')); ?>" class="iq-waves-effect" ><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Banner</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-list')): ?>
               <a href="<?php echo e(route('products.index')); ?>" class="iq-waves-effect" ><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Product</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order-list')): ?>
               <a href="<?php echo e(route('orders.index')); ?>" class="iq-waves-effect" ><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Order</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
            <li>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('file-list')): ?>
               <a href="<?php echo e(route('media.index')); ?>" class="iq-waves-effect" ><span class="ripple rippleEffect"></span><i class="lab la-elementor iq-arrow-left"></i><span>Media</span><i class="ri-arrow-right-s-line iq-arrow-right"></i></a>
               <?php endif; ?>
            </li>
         </ul>
      </nav>
   </div>
</div><?php /**PATH D:\DATN\tungstore\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>