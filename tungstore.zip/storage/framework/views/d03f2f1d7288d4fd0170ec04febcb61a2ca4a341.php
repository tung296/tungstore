
<?php $__env->startSection('body'); ?>
<div id="loading">
    <div id="loading-center">
    </div>
 </div>
 <div class="wrapper">
    <!-- Sidebar  -->
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- TOP Nav Bar -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- TOP Nav Bar END -->
    <!-- Page Content  -->
    <div id="content-page" class="content-page">
       <div class="container-fluid">
           <?php echo $__env->yieldContent('content'); ?>
       </div>
    </div>
 </div>
 <!-- Wrapper END -->
 <!-- Footer -->
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sources', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/layouts/index.blade.php ENDPATH**/ ?>