
<?php $__env->startSection('body'); ?>
<div id="loading">
    <div id="loading-center">
    </div>
 </div>
 <section class="sign-in-page">
    <div class="container p-0" id="sign-in-page-box">
    
          <div class="bg-white form-container sign-in-container">
              <div class="sign-in-page-data">
                <div class="sign-in-from w-100 m-auto">
                    <h1 class="mb-3 text-center">Sign in</h1>
                    <p class="text-center text-dark">Enter your email address and password to access admin panel.</p>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <?php $__currentLoopData = $errors -> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($err); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <form class="mt-4" method="POST" action="<?php echo e(route('admin.login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail2">Email address</label>
                            <input type="email" name="email" class="form-control mb-0" id="exampleInputEmail2" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword2">Password</label>
                            <a href="#" class="float-right">Forgot password?</a>
                            <input type="password" name="password" class="form-control mb-0" id="exampleInputPassword2" placeholder="Password">
                        </div>
                        <div class="d-inline-block w-100">
                            <div class="custom-control custom-checkbox d-inline-block mt-2 pt-1">
                                <input type="checkbox" class="custom-control-input" id="customCheck2">
                                <label class="custom-control-label" for="customCheck1">Remember Me</label>
                            </div>
                        </div>
                        <div class="sign-info">
                            <button type="submit" class="btn btn-primary mb-2">Sign in</button>
                            <span class="text-dark dark-color d-block line-height-2">Don't have an account? <a href="#">Sign up</a></span>
                        </div>
                    </form>
                </div>
            </div>
          </div>
          <div class="overlay-container">
              <div class="overlay">
                  <div class="overlay-panel overlay-left">
                      <a class="sign-in-logo mb-5" href="#"><img src="images/logo-full.png" class="img-fluid" alt="logo"></a>
                      <p>To Keep connected with us please login with your personal info</p>
                      <button class="btn iq-border-primary mt-2" id="signIn">Sign In</button>
                  </div>
                  <div class="overlay-panel overlay-right">
                      <a class="sign-in-logo mb-5" href="#"><img src="images/logo-full.png" class="img-fluid" alt="logo"></a>
                      <p>Enter your personal details and start journey with us</p>
                      <button class="btn iq-border-primary mt-2" id="signUp">Sign Up</button>
                  </div>
              </div>
          </div>
      </div>
  </section>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.sources', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/auth/login.blade.php ENDPATH**/ ?>