
<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-success">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>
<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('signup')); ?>" method="post" class="beta-form-checkout">
                <?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<h4>Đăng kí</h4>
						<div class="space20">&nbsp;</div>
						<div class="form-block">
							<label for="email">Email address*</label>
							<input type="email" name="email" id="email">
                            <?php if($errors->has('email')): ?>
                                <p class="text-danger mt-2"><?php echo e($errors->first('email')); ?></p>
                            <?php endif; ?>
						</div>
						<div class="form-block">
							<label for="your_last_name">Name*</label>
							<input type="text" name="name" id="your_last_name" >
                            <?php if($errors->has('name')): ?>
                                <p class="text-danger mt-2"><?php echo e($errors->first('name')); ?></p>
                            <?php endif; ?>
						</div>
						<div class="form-block">
							<label for="phone">Phone*</label>
							<input type="text" name="phone" id="phone" >
                            <?php if($errors->has('phone')): ?>
                                <p class="text-danger mt-2"><?php echo e($errors->first('phone')); ?></p>
                            <?php endif; ?>
						</div>
						<div class="form-block">
							<label for="phone">Password*</label>
							<input type="password" name="password" id="password" >
                            <?php if($errors->has('password')): ?>
                                <p class="text-danger mt-2"><?php echo e($errors->first('password')); ?></p>
                            <?php endif; ?>
						</div>
						<div class="form-block">
							<button type="submit" class="btn btn-primary">Register</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATN\tungstore\resources\views/pages/auth/signup.blade.php ENDPATH**/ ?>